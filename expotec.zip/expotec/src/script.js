function startGame() {
    document.getElementById("login-container").style.display = "none";
    document.getElementById("next-phase-container").style.display = "flex";
    document.body.style.backgroundColor = "black";
    setTimeout(function() {
        document.getElementById("next-phase-container").style.opacity = "1";
    }, 100);
}