# Expotec

A Pen created on CodePen.io. Original URL: [https://codepen.io/Sixxis/pen/rNbbovv](https://codepen.io/Sixxis/pen/rNbbovv).

